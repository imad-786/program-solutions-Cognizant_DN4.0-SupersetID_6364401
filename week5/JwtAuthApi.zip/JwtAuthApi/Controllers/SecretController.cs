﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JwtAuthApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SecretController : ControllerBase
    {
        [Authorize]
        [HttpGet("data")]
        public IActionResult GetSecretData()
        {
            return Ok("This is protected data. You are authorized!");
        }
    }
}
