﻿using Microsoft.AspNetCore.Mvc;
using EmployeeCrudAPI.Models;

namespace EmployeeCrudAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeController : ControllerBase
    {
        private static List<Employee> _employees = new()
        {
            new Employee { Id = 1, Name = "Alice", Salary = 50000, Permanent = true },
            new Employee { Id = 2, Name = "Bob", Salary = 60000, Permanent = false }
        };

        [HttpPut("{id}")]
        [ProducesResponseType(typeof(Employee), 200)]
        [ProducesResponseType(400)]
        public ActionResult<Employee> UpdateEmployee(int id, [FromBody] Employee updatedEmp)
        {
            if (id <= 0)
                return BadRequest("Invalid employee id");

            var existingEmp = _employees.FirstOrDefault(e => e.Id == id);
            if (existingEmp == null)
                return BadRequest("Invalid employee id");

            existingEmp.Name = updatedEmp.Name;
            existingEmp.Salary = updatedEmp.Salary;
            existingEmp.Permanent = updatedEmp.Permanent;
            existingEmp.Department = updatedEmp.Department;
            existingEmp.Skills = updatedEmp.Skills;
            existingEmp.DateOfBirth = updatedEmp.DateOfBirth;

            return Ok(existingEmp);
        }
    }
}
